import json,os,pathlib,shlex,subprocess,datetime,re
root=pathlib.Path.cwd(); evidence=root/'tmp/4410/evidence'; evidence.mkdir(exist_ok=True)
env=os.environ.copy()
for k in list(env):
 if k.startswith(('TEST_DB_', 'EMAIL_SMTP_')):env.pop(k)
for line in (root/'.env').read_text().splitlines():
 if line.startswith('TEST_DB_') and '=' in line:
  k,v=line.split('=',1);env[k]=shlex.split(v)[0]
env['PHX_TEST_TEMPLATE']=(root/'tmp/4410/setup/template-name.txt').read_text().strip();env['GOMAXPROCS']='4'
env['PATH']=str(root/'.devbox/nix/profile/default/bin')+':'+env['PATH']
# No lifecycle overlay is needed in these binaries: PHX_TEST_TEMPLATE selects the verified template.
for variant,label in [('baseline','a1'),('candidate','b1'),('baseline','a2'),('candidate','b2'),('baseline','a3'),('candidate','b3'),('diagnostic-a','diagnostic-a'),('diagnostic-b','diagnostic-b')]:
 out=evidence/label
 if out.exists():
  assert json.loads((out/'command.json').read_text())['exit_code']==0
 else:out.mkdir()
 with (out/'host.txt').open('w') as f:
  f.write(datetime.datetime.now(datetime.timezone.utc).isoformat()+'\n');f.flush()
  for cmd in [['uptime'],['ps','-Ao','pcpu,comm','-r'],['pgrep','-fl','go test'],['tmutil','status']]:
   result=subprocess.run(cmd,text=True,capture_output=True);f.write('$ '+' '.join(cmd)+'\n'+('\n'.join(result.stdout.splitlines()[:12]))+'\nexit='+str(result.returncode)+'\n')
 cmd=[str(root/'tmp/4410'/f'{variant}.test'),'-test.run=^TestFullProductionRouterGolden$','-test.count=1','-test.parallel=8',f'-runtime-checkpoint-output={out}/raw.json','-runtime-checkpoint-workload=checkpoint-1-v1']
 if (out/'raw.json').exists():
  result=subprocess.CompletedProcess(cmd,0)
 else:
  with (out/'test.log').open('w') as f:result=subprocess.run(cmd,cwd=root/'backend/api',env=env,stdout=f,stderr=subprocess.STDOUT)
 (out/'command.json').write_text(json.dumps({'argv':cmd,'exit_code':result.returncode,'gomaxprocs':4,'template':env['PHX_TEST_TEMPLATE'],'test_db_source':'.env'},indent=2)+'\n')
 print(label,'exit',result.returncode,flush=True)
 if result.returncode:raise SystemExit(result.returncode)
 raw=json.loads((out/'raw.json').read_text())
 for run in raw['runs']:
  for scenario in run:
   for sample in scenario['samples']:
    if 'error_body' in sample:
     sample['error_body']=re.sub(r'("instance":")[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}(")',lambda m:m.group(1)+'00000000-0000-0000-0000-000000000000'+('"' if m.group(2) else ''),sample['error_body'])
 (out/'reporting.json').write_text(json.dumps(raw)+'\n')
 subprocess.run(['python3','scripts/runtime-checkpoint-report.py',str(out/'reporting.json'),str(out)],check=True)
for i in range(1,4):subprocess.run(['python3','scripts/runtime-checkpoint-compare.py',str(evidence/f'a{i}/summary.json'),str(evidence/f'b{i}/summary.json'),str(evidence/f'pair{i}')],check=True)
