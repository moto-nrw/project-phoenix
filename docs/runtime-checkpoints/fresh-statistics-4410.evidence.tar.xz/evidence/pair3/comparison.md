# Runtime workload checkpoint-1-v1: baseline versus candidate

Each cell shows baseline → candidate. Latency uses nearest-rank percentiles.
Latency changes count as material only beyond relative 20.0% and absolute 0.500 ms; any change to another metric is material. The Material column of each table lists only that table's statistic.

## Median of three runs

| Scenario | p50 ms | p95 ms | Queries/run | Rows/run¹ | Pool wait ms | Lock observations | Material |
|---|---:|---:|---:|---:|---:|---:|---|
| timetable.not-found | 0.972 → 1.001 (+3.0%) | 1.546 → 1.400 (-9.4%) | 150.000 → 150.000 (+0.0%) | 30.000 → 30.000 (+0.0%) | 0.000 → 0.000 | 0.000 → 0.000 | none |
| organization-tenancy.resolve | 2.546 → 2.689 (+5.6%) | 3.119 → 3.475 (+11.4%) | 390.000 → 390.000 (+0.0%) | 90.000 → 90.000 (+0.0%) | 0.000 → 0.000 | 0.000 → 0.000 | none |
| facilities.update | 1.438 → 1.361 (-5.4%) | 1.849 → 1.852 (+0.2%) | 210.000 → 210.000 (+0.0%) | 120.000 → 120.000 (+0.0%) | 0.000 → 0.000 | 0.000 → 0.000 | none |
| facilities.list | 1.941 → 1.709 (-12.0%) | 2.297 → 2.083 (-9.3%) | 210.000 → 210.000 (+0.0%) | 390.000 → 390.000 (+0.0%) | 0.000 → 0.000 | 0.000 → 0.000 | none |
| school-structure.list | 1.993 → 2.079 (+4.3%) | 2.706 → 2.784 (+2.9%) | 240.000 → 240.000 (+0.0%) | 330.000 → 330.000 (+0.0%) | 0.000 → 0.000 | 0.000 → 0.000 | none |
| people-directory.guardians | 1.428 → 1.547 (+8.3%) | 2.072 → 1.923 (-7.2%) | 180.000 → 180.000 (+0.0%) | 1530.000 → 1530.000 (+0.0%) | 0.000 → 0.000 | 0.000 → 0.000 | none |
| timetable.activities | 2.045 → 2.502 (+22.3%) | 2.579 → 3.532 (+37.0%) | 240.000 → 240.000 (+0.0%) | 690.000 → 690.000 (+0.0%) | 0.000 → 0.000 | 0.000 → 0.000 | latency_p95_ms |
| timetable.categories | 0.995 → 1.201 (+20.7%) | 1.274 → 1.608 (+26.3%) | 150.000 → 150.000 (+0.0%) | 360.000 → 360.000 (+0.0%) | 0.000 → 0.000 | 0.000 → 0.000 | none |
| school-calendar.periods | 1.841 → 1.987 (+7.9%) | 2.489 → 2.489 (-0.0%) | 210.000 → 210.000 (+0.0%) | 90.000 → 90.000 (+0.0%) | 0.000 → 0.000 | 0.000 → 0.000 | none |
| care-plan.offerings | 1.317 → 1.115 (-15.3%) | 1.623 → 2.003 (+23.5%) | 180.000 → 180.000 (+0.0%) | 330.000 → 330.000 (+0.0%) | 0.000 → 0.000 | 0.000 → 0.000 | none |
| communication.messages | 4.321 → 2.644 (-38.8%) | 5.948 → 3.347 (-43.7%) | 150.000 → 150.000 (+0.0%) | 30.000 → 30.000 (+0.0%) | 0.000 → 0.000 | 0.000 → 0.000 | latency_p50_ms, latency_p95_ms |
| appointments.calendar | 2.417 → 2.691 (+11.3%) | 2.947 → 3.663 (+24.3%) | 270.000 → 270.000 (+0.0%) | 90.000 → 90.000 (+0.0%) | 0.000 → 0.000 | 0.000 → 0.000 | latency_p95_ms |
| settings.schema | 2.126 → 1.958 (-7.9%) | 2.965 → 2.673 (-9.8%) | 150.000 → 150.000 (+0.0%) | 30.000 → 30.000 (+0.0%) | 0.000 → 0.000 | 0.000 → 0.000 | none |
| meal-plan.list | 1.274 → 1.229 (-3.5%) | 1.831 → 1.413 (-22.8%) | 180.000 → 180.000 (+0.0%) | 30.000 → 30.000 (+0.0%) | 0.000 → 0.000 | 0.000 → 0.000 | none |
| feedback.list | 0.928 → 0.933 (+0.5%) | 1.628 → 1.235 (-24.2%) | 150.000 → 150.000 (+0.0%) | 30.000 → 30.000 (+0.0%) | 0.000 → 0.000 | 0.000 → 0.000 | none |
| school-membership.staff | 4.331 → 4.360 (+0.7%) | 5.582 → 6.276 (+12.4%) | 450.000 → 450.000 (+0.0%) | 1170.000 → 1170.000 (+0.0%) | 0.000 → 0.000 | 0.000 → 0.000 | none |
| facilities.invalid-id | 0.665 → 0.805 (+21.1%) | 0.864 → 1.154 (+33.6%) | 120.000 → 120.000 (+0.0%) | 30.000 → 30.000 (+0.0%) | 0.000 → 0.000 | 0.000 → 0.000 | none |
| timetable.invalid-id | 0.664 → 0.750 (+13.0%) | 0.858 → 1.030 (+20.1%) | 120.000 → 120.000 (+0.0%) | 30.000 → 30.000 (+0.0%) | 0.000 → 0.000 | 0.000 → 0.000 | none |
| people-directory.invalid-id | 0.652 → 0.769 (+17.9%) | 0.919 → 1.344 (+46.3%) | 120.000 → 120.000 (+0.0%) | 30.000 → 30.000 (+0.0%) | 0.000 → 0.000 | 0.000 → 0.000 | none |
| security.unauthenticated | 0.043 → 0.026 (-37.8%) | 0.170 → 0.063 (-63.2%) | 0.000 → 0.000 | 0.000 → 0.000 | 0.000 → 0.000 | 0.000 → 0.000 | none |
| delivery.provider-unavailable | 8.122 → 7.966 (-1.9%) | 9.806 → 10.758 (+9.7%) | 1140.000 → 1140.000 (+0.0%) | 30.000 → 30.000 (+0.0%) | 0.000 → 0.000 | 0.000 → 0.000 | none |
| delivery.render-failure | 7.493 → 6.886 (-8.1%) | 9.143 → 8.505 (-7.0%) | 1080.000 → 1080.000 (+0.0%) | 30.000 → 30.000 (+0.0%) | 0.000 → 0.000 | 0.000 → 0.000 | none |
| delivery.idle | 4.738 → 4.693 (-1.0%) | 5.554 → 5.675 (+2.2%) | 720.000 → 720.000 (+0.0%) | 0.000 → 0.000 | 0.000 → 0.000 | 0.000 → 0.000 | none |
| timetable.materialize-create | 5.354 → 5.520 (+3.1%) | 6.510 → 6.468 (-0.6%) | 570.000 → 570.000 (+0.0%) | 30.000 → 30.000 (+0.0%) | 0.000 → 0.000 | 0.000 → 0.000 | none |
| timetable.materialize-existing | 3.867 → 4.642 (+20.0%) | 5.125 → 5.802 (+13.2%) | 510.000 → 510.000 (+0.0%) | 0.000 → 0.000 | 0.000 → 0.000 | 0.000 → 0.000 | job_duration_total_ms, latency_p50_ms |

## Worst of three runs

The worst run is the maximum of each metric across runs, chosen per metric.

| Scenario | p50 ms | p95 ms | Queries/run | Rows/run¹ | Pool wait ms | Lock observations | Material |
|---|---:|---:|---:|---:|---:|---:|---|
| timetable.not-found | 1.153 → 1.140 (-1.1%) | 2.102 → 1.695 (-19.4%) | 150.000 → 150.000 (+0.0%) | 30.000 → 30.000 (+0.0%) | 0.000 → 0.000 | 0.000 → 0.000 | none |
| organization-tenancy.resolve | 2.896 → 2.699 (-6.8%) | 4.028 → 4.119 (+2.3%) | 390.000 → 390.000 (+0.0%) | 90.000 → 90.000 (+0.0%) | 0.000 → 0.000 | 0.000 → 0.000 | none |
| facilities.update | 1.806 → 1.523 (-15.6%) | 3.940 → 2.008 (-49.0%) | 210.000 → 210.000 (+0.0%) | 120.000 → 120.000 (+0.0%) | 0.000 → 0.000 | 0.000 → 0.000 | latency_p95_ms |
| facilities.list | 1.970 → 1.935 (-1.8%) | 2.345 → 2.500 (+6.6%) | 210.000 → 210.000 (+0.0%) | 390.000 → 390.000 (+0.0%) | 0.000 → 0.000 | 0.000 → 0.000 | none |
| school-structure.list | 2.173 → 2.261 (+4.0%) | 3.513 → 2.823 (-19.6%) | 240.000 → 240.000 (+0.0%) | 330.000 → 330.000 (+0.0%) | 0.000 → 0.000 | 0.000 → 0.000 | none |
| people-directory.guardians | 1.648 → 1.658 (+0.6%) | 2.689 → 2.005 (-25.4%) | 180.000 → 180.000 (+0.0%) | 1530.000 → 1530.000 (+0.0%) | 0.000 → 0.000 | 0.000 → 0.000 | latency_p95_ms |
| timetable.activities | 2.320 → 2.629 (+13.3%) | 3.437 → 3.621 (+5.4%) | 240.000 → 240.000 (+0.0%) | 690.000 → 690.000 (+0.0%) | 0.000 → 0.000 | 0.000 → 0.000 | none |
| timetable.categories | 1.100 → 1.228 (+11.7%) | 1.844 → 2.103 (+14.1%) | 150.000 → 150.000 (+0.0%) | 360.000 → 360.000 (+0.0%) | 0.000 → 0.000 | 0.000 → 0.000 | none |
| school-calendar.periods | 1.986 → 2.207 (+11.1%) | 2.575 → 2.637 (+2.4%) | 210.000 → 210.000 (+0.0%) | 90.000 → 90.000 (+0.0%) | 0.000 → 0.000 | 0.000 → 0.000 | none |
| care-plan.offerings | 1.651 → 1.713 (+3.8%) | 2.131 → 2.225 (+4.4%) | 180.000 → 180.000 (+0.0%) | 330.000 → 330.000 (+0.0%) | 0.000 → 0.000 | 0.000 → 0.000 | none |
| communication.messages | 4.901 → 2.668 (-45.6%) | 10.880 → 3.352 (-69.2%) | 150.000 → 150.000 (+0.0%) | 30.000 → 30.000 (+0.0%) | 0.000 → 0.000 | 0.000 → 0.000 | latency_p50_ms, latency_p95_ms |
| appointments.calendar | 3.167 → 2.861 (-9.7%) | 6.577 → 3.859 (-41.3%) | 270.000 → 270.000 (+0.0%) | 90.000 → 90.000 (+0.0%) | 0.000 → 0.000 | 0.000 → 0.000 | latency_p95_ms |
| settings.schema | 2.541 → 2.168 (-14.7%) | 3.250 → 2.747 (-15.5%) | 150.000 → 150.000 (+0.0%) | 30.000 → 30.000 (+0.0%) | 0.000 → 0.000 | 0.000 → 0.000 | none |
| meal-plan.list | 1.740 → 1.281 (-26.3%) | 5.203 → 1.954 (-62.5%) | 180.000 → 180.000 (+0.0%) | 30.000 → 30.000 (+0.0%) | 0.000 → 0.000 | 0.000 → 0.000 | latency_p95_ms |
| feedback.list | 1.233 → 0.982 (-20.3%) | 1.664 → 1.399 (-15.9%) | 150.000 → 150.000 (+0.0%) | 30.000 → 30.000 (+0.0%) | 0.000 → 0.000 | 0.000 → 0.000 | none |
| school-membership.staff | 4.425 → 4.389 (-0.8%) | 6.063 → 6.403 (+5.6%) | 450.000 → 450.000 (+0.0%) | 1170.000 → 1170.000 (+0.0%) | 0.000 → 0.000 | 0.000 → 0.000 | none |
| facilities.invalid-id | 0.719 → 0.808 (+12.4%) | 0.937 → 1.174 (+25.2%) | 120.000 → 120.000 (+0.0%) | 30.000 → 30.000 (+0.0%) | 0.000 → 0.000 | 0.000 → 0.000 | none |
| timetable.invalid-id | 0.739 → 0.975 (+31.8%) | 0.964 → 1.331 (+38.1%) | 120.000 → 120.000 (+0.0%) | 30.000 → 30.000 (+0.0%) | 0.000 → 0.000 | 0.000 → 0.000 | none |
| people-directory.invalid-id | 0.730 → 0.976 (+33.6%) | 1.074 → 1.879 (+75.0%) | 120.000 → 120.000 (+0.0%) | 30.000 → 30.000 (+0.0%) | 0.000 → 0.000 | 0.000 → 0.000 | latency_p95_ms |
| security.unauthenticated | 0.048 → 0.030 (-38.2%) | 0.173 → 0.101 (-41.6%) | 0.000 → 0.000 | 0.000 → 0.000 | 0.000 → 0.000 | 0.000 → 0.000 | none |
| delivery.provider-unavailable | 8.333 → 8.253 (-1.0%) | 11.174 → 16.400 (+46.8%) | 1140.000 → 1140.000 (+0.0%) | 30.000 → 30.000 (+0.0%) | 0.000 → 0.000 | 0.000 → 0.000 | latency_p95_ms |
| delivery.render-failure | 7.701 → 8.583 (+11.5%) | 12.582 → 11.842 (-5.9%) | 1080.000 → 1080.000 (+0.0%) | 30.000 → 30.000 (+0.0%) | 0.000 → 0.000 | 0.000 → 0.000 | none |
| delivery.idle | 5.045 → 4.893 (-3.0%) | 7.175 → 6.541 (-8.8%) | 720.000 → 720.000 (+0.0%) | 0.000 → 0.000 | 0.000 → 0.000 | 0.000 → 0.000 | none |
| timetable.materialize-create | 5.711 → 5.756 (+0.8%) | 40.856 → 8.234 (-79.8%) | 570.000 → 570.000 (+0.0%) | 30.000 → 30.000 (+0.0%) | 0.000 → 0.000 | 0.000 → 0.000 | job_duration_total_ms, latency_p95_ms |
| timetable.materialize-existing | 4.716 → 4.862 (+3.1%) | 5.893 → 14.200 (+141.0%) | 510.000 → 510.000 (+0.0%) | 0.000 → 0.000 | 0.000 → 0.000 | 0.000 → 0.000 | latency_p95_ms |

¹ HTTP: driver-reported rows returned or changed, not distinct database rows. Worker: outbox rows claimed or timetable instances created.

## Material changes

- `facilities.update` `latency_p95_ms` worst: 3.940 → 2.008
- `people-directory.guardians` `latency_p95_ms` worst: 2.689 → 2.005
- `timetable.activities` `latency_p95_ms` median: 2.579 → 3.532
- `communication.messages` `latency_p50_ms` median: 4.321 → 2.644
- `communication.messages` `latency_p50_ms` worst: 4.901 → 2.668
- `communication.messages` `latency_p95_ms` median: 5.948 → 3.347
- `communication.messages` `latency_p95_ms` worst: 10.880 → 3.352
- `appointments.calendar` `latency_p95_ms` median: 2.947 → 3.663
- `appointments.calendar` `latency_p95_ms` worst: 6.577 → 3.859
- `meal-plan.list` `latency_p95_ms` worst: 5.203 → 1.954
- `people-directory.invalid-id` `latency_p95_ms` worst: 1.074 → 1.879
- `delivery.provider-unavailable` `latency_p95_ms` worst: 11.174 → 16.400
- `timetable.materialize-create` `latency_p95_ms` worst: 40.856 → 8.234
- `timetable.materialize-create` `job_duration_total_ms` worst: 279.631 → 176.872
- `timetable.materialize-existing` `latency_p50_ms` median: 3.867 → 4.642
- `timetable.materialize-existing` `latency_p95_ms` worst: 5.893 → 14.200
- `timetable.materialize-existing` `job_duration_total_ms` median: 118.414 → 146.343

## Classification counts across all scenarios, metrics, and statistics

- unchanged: 888
- within-tolerance: 93
- material: 17
- coverage: 100
