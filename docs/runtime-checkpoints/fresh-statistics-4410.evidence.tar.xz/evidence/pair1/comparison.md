# Runtime workload checkpoint-1-v1: baseline versus candidate

Each cell shows baseline → candidate. Latency uses nearest-rank percentiles.
Latency changes count as material only beyond relative 20.0% and absolute 0.500 ms; any change to another metric is material. The Material column of each table lists only that table's statistic.

## Median of three runs

| Scenario | p50 ms | p95 ms | Queries/run | Rows/run¹ | Pool wait ms | Lock observations | Material |
|---|---:|---:|---:|---:|---:|---:|---|
| timetable.not-found | 0.910 → 1.152 (+26.6%) | 1.496 → 1.347 (-9.9%) | 150.000 → 150.000 (+0.0%) | 30.000 → 30.000 (+0.0%) | 0.000 → 0.000 | 0.000 → 0.000 | none |
| organization-tenancy.resolve | 2.333 → 2.577 (+10.5%) | 2.792 → 3.659 (+31.0%) | 390.000 → 390.000 (+0.0%) | 90.000 → 90.000 (+0.0%) | 0.000 → 0.000 | 0.000 → 0.000 | latency_p95_ms |
| facilities.update | 1.397 → 1.569 (+12.3%) | 1.797 → 2.521 (+40.3%) | 210.000 → 210.000 (+0.0%) | 120.000 → 120.000 (+0.0%) | 0.000 → 0.000 | 0.000 → 0.000 | latency_p95_ms |
| facilities.list | 1.889 → 2.311 (+22.3%) | 2.532 → 4.390 (+73.3%) | 210.000 → 210.000 (+0.0%) | 390.000 → 390.000 (+0.0%) | 0.000 → 0.000 | 0.000 → 0.000 | latency_p95_ms |
| school-structure.list | 1.907 → 2.332 (+22.3%) | 2.199 → 3.172 (+44.2%) | 240.000 → 240.000 (+0.0%) | 330.000 → 330.000 (+0.0%) | 0.000 → 0.000 | 0.000 → 0.000 | latency_p95_ms |
| people-directory.guardians | 1.394 → 1.739 (+24.8%) | 1.871 → 3.095 (+65.5%) | 180.000 → 180.000 (+0.0%) | 1530.000 → 1530.000 (+0.0%) | 0.000 → 0.000 | 0.000 → 0.000 | latency_p95_ms |
| timetable.activities | 2.148 → 2.595 (+20.8%) | 2.706 → 3.544 (+31.0%) | 240.000 → 240.000 (+0.0%) | 690.000 → 690.000 (+0.0%) | 0.000 → 0.000 | 0.000 → 0.000 | latency_p95_ms |
| timetable.categories | 1.006 → 1.262 (+25.5%) | 1.308 → 2.038 (+55.9%) | 150.000 → 150.000 (+0.0%) | 360.000 → 360.000 (+0.0%) | 0.000 → 0.000 | 0.000 → 0.000 | latency_p95_ms |
| school-calendar.periods | 1.737 → 1.995 (+14.9%) | 2.243 → 3.043 (+35.7%) | 210.000 → 210.000 (+0.0%) | 90.000 → 90.000 (+0.0%) | 0.000 → 0.000 | 0.000 → 0.000 | latency_p95_ms |
| care-plan.offerings | 1.280 → 1.449 (+13.2%) | 1.787 → 2.350 (+31.5%) | 180.000 → 180.000 (+0.0%) | 330.000 → 330.000 (+0.0%) | 0.000 → 0.000 | 0.000 → 0.000 | latency_p95_ms |
| communication.messages | 4.098 → 2.820 (-31.2%) | 4.792 → 3.450 (-28.0%) | 150.000 → 150.000 (+0.0%) | 30.000 → 30.000 (+0.0%) | 0.000 → 0.000 | 0.000 → 0.000 | latency_p50_ms, latency_p95_ms |
| appointments.calendar | 2.484 → 2.938 (+18.3%) | 2.936 → 4.258 (+45.0%) | 270.000 → 270.000 (+0.0%) | 90.000 → 90.000 (+0.0%) | 0.000 → 0.000 | 0.000 → 0.000 | latency_p95_ms |
| settings.schema | 1.785 → 2.063 (+15.6%) | 2.508 → 3.397 (+35.4%) | 150.000 → 150.000 (+0.0%) | 30.000 → 30.000 (+0.0%) | 0.000 → 0.000 | 0.000 → 0.000 | latency_p95_ms |
| meal-plan.list | 1.123 → 1.266 (+12.7%) | 1.331 → 1.864 (+40.1%) | 180.000 → 180.000 (+0.0%) | 30.000 → 30.000 (+0.0%) | 0.000 → 0.000 | 0.000 → 0.000 | latency_p95_ms |
| feedback.list | 0.914 → 0.987 (+8.0%) | 1.335 → 1.451 (+8.7%) | 150.000 → 150.000 (+0.0%) | 30.000 → 30.000 (+0.0%) | 0.000 → 0.000 | 0.000 → 0.000 | none |
| school-membership.staff | 4.041 → 5.402 (+33.7%) | 4.919 → 8.956 (+82.1%) | 450.000 → 450.000 (+0.0%) | 1170.000 → 1170.000 (+0.0%) | 0.000 → 0.000 | 0.000 → 0.000 | latency_p50_ms, latency_p95_ms |
| facilities.invalid-id | 0.710 → 0.895 (+26.1%) | 1.177 → 1.899 (+61.4%) | 120.000 → 120.000 (+0.0%) | 30.000 → 30.000 (+0.0%) | 0.000 → 0.000 | 0.000 → 0.000 | latency_p95_ms |
| timetable.invalid-id | 0.703 → 0.714 (+1.7%) | 0.952 → 1.029 (+8.1%) | 120.000 → 120.000 (+0.0%) | 30.000 → 30.000 (+0.0%) | 0.000 → 0.000 | 0.000 → 0.000 | none |
| people-directory.invalid-id | 0.773 → 0.638 (-17.5%) | 1.117 → 1.051 (-6.0%) | 120.000 → 120.000 (+0.0%) | 30.000 → 30.000 (+0.0%) | 0.000 → 0.000 | 0.000 → 0.000 | none |
| security.unauthenticated | 0.026 → 0.032 (+26.5%) | 0.042 → 0.150 (+260.7%) | 0.000 → 0.000 | 0.000 → 0.000 | 0.000 → 0.000 | 0.000 → 0.000 | none |
| delivery.provider-unavailable | 7.659 → 8.227 (+7.4%) | 8.934 → 16.124 (+80.5%) | 1140.000 → 1140.000 (+0.0%) | 30.000 → 30.000 (+0.0%) | 0.000 → 0.000 | 0.000 → 0.000 | latency_p95_ms |
| delivery.render-failure | 6.536 → 6.771 (+3.6%) | 7.800 → 7.817 (+0.2%) | 1080.000 → 1080.000 (+0.0%) | 30.000 → 30.000 (+0.0%) | 0.000 → 0.000 | 0.000 → 0.000 | none |
| delivery.idle | 4.190 → 4.199 (+0.2%) | 5.074 → 8.540 (+68.3%) | 720.000 → 720.000 (+0.0%) | 0.000 → 0.000 | 0.000 → 0.000 | 0.000 → 0.000 | latency_p95_ms |
| timetable.materialize-create | 4.937 → 5.440 (+10.2%) | 5.877 → 7.741 (+31.7%) | 570.000 → 570.000 (+0.0%) | 30.000 → 30.000 (+0.0%) | 0.000 → 0.000 | 0.000 → 0.000 | latency_p95_ms |
| timetable.materialize-existing | 3.732 → 4.112 (+10.2%) | 4.578 → 5.118 (+11.8%) | 510.000 → 510.000 (+0.0%) | 0.000 → 0.000 | 0.000 → 0.000 | 0.000 → 0.000 | none |

## Worst of three runs

The worst run is the maximum of each metric across runs, chosen per metric.

| Scenario | p50 ms | p95 ms | Queries/run | Rows/run¹ | Pool wait ms | Lock observations | Material |
|---|---:|---:|---:|---:|---:|---:|---|
| timetable.not-found | 0.962 → 1.380 (+43.4%) | 4.520 → 2.306 (-49.0%) | 150.000 → 150.000 (+0.0%) | 30.000 → 30.000 (+0.0%) | 0.000 → 0.000 | 0.000 → 0.000 | latency_p95_ms |
| organization-tenancy.resolve | 2.341 → 2.748 (+17.4%) | 3.116 → 3.755 (+20.5%) | 390.000 → 390.000 (+0.0%) | 90.000 → 90.000 (+0.0%) | 0.000 → 0.000 | 0.000 → 0.000 | latency_p95_ms |
| facilities.update | 1.450 → 1.667 (+14.9%) | 1.813 → 4.034 (+122.5%) | 210.000 → 210.000 (+0.0%) | 120.000 → 120.000 (+0.0%) | 0.000 → 0.000 | 0.000 → 0.000 | latency_p95_ms |
| facilities.list | 2.017 → 2.346 (+16.3%) | 2.641 → 6.211 (+135.2%) | 210.000 → 210.000 (+0.0%) | 390.000 → 390.000 (+0.0%) | 0.000 → 0.000 | 0.000 → 0.000 | latency_p95_ms |
| school-structure.list | 2.015 → 3.702 (+83.8%) | 2.716 → 7.053 (+159.7%) | 240.000 → 240.000 (+0.0%) | 330.000 → 330.000 (+0.0%) | 0.000 → 0.000 | 0.000 → 0.000 | latency_p50_ms, latency_p95_ms |
| people-directory.guardians | 1.550 → 1.959 (+26.3%) | 1.916 → 3.593 (+87.5%) | 180.000 → 180.000 (+0.0%) | 1530.000 → 1530.000 (+0.0%) | 0.000 → 0.000 | 0.000 → 0.000 | latency_p95_ms |
| timetable.activities | 2.278 → 2.688 (+18.0%) | 2.767 → 3.663 (+32.4%) | 240.000 → 240.000 (+0.0%) | 690.000 → 690.000 (+0.0%) | 0.000 → 0.000 | 0.000 → 0.000 | latency_p95_ms |
| timetable.categories | 1.042 → 1.953 (+87.4%) | 1.369 → 4.310 (+214.8%) | 150.000 → 150.000 (+0.0%) | 360.000 → 360.000 (+0.0%) | 0.000 → 0.000 | 0.000 → 0.000 | latency_p50_ms, latency_p95_ms |
| school-calendar.periods | 1.903 → 2.432 (+27.8%) | 2.266 → 9.023 (+298.1%) | 210.000 → 210.000 (+0.0%) | 90.000 → 90.000 (+0.0%) | 0.000 → 0.000 | 0.000 → 0.000 | latency_p50_ms, latency_p95_ms |
| care-plan.offerings | 1.289 → 2.996 (+132.3%) | 1.818 → 7.295 (+301.2%) | 180.000 → 180.000 (+0.0%) | 330.000 → 330.000 (+0.0%) | 0.000 → 0.000 | 0.000 → 0.000 | latency_p50_ms, latency_p95_ms |
| communication.messages | 4.277 → 3.352 (-21.6%) | 4.833 → 5.019 (+3.8%) | 150.000 → 150.000 (+0.0%) | 30.000 → 30.000 (+0.0%) | 0.000 → 0.000 | 0.000 → 0.000 | latency_p50_ms |
| appointments.calendar | 2.508 → 3.343 (+33.3%) | 3.394 → 9.037 (+166.3%) | 270.000 → 270.000 (+0.0%) | 90.000 → 90.000 (+0.0%) | 0.000 → 0.000 | 0.000 → 0.000 | latency_p50_ms, latency_p95_ms |
| settings.schema | 1.893 → 3.121 (+64.8%) | 2.702 → 5.992 (+121.7%) | 150.000 → 150.000 (+0.0%) | 30.000 → 30.000 (+0.0%) | 0.000 → 0.000 | 0.000 → 0.000 | latency_p50_ms, latency_p95_ms |
| meal-plan.list | 1.152 → 2.510 (+117.8%) | 1.524 → 5.883 (+286.1%) | 180.000 → 180.000 (+0.0%) | 30.000 → 30.000 (+0.0%) | 0.000 → 0.000 | 0.000 → 0.000 | latency_p50_ms, latency_p95_ms |
| feedback.list | 0.971 → 1.219 (+25.6%) | 1.408 → 1.724 (+22.5%) | 150.000 → 150.000 (+0.0%) | 30.000 → 30.000 (+0.0%) | 0.000 → 0.000 | 0.000 → 0.000 | none |
| school-membership.staff | 4.136 → 5.665 (+37.0%) | 5.684 → 11.449 (+101.4%) | 450.000 → 450.000 (+0.0%) | 1170.000 → 1170.000 (+0.0%) | 0.000 → 0.000 | 0.000 → 0.000 | latency_p50_ms, latency_p95_ms |
| facilities.invalid-id | 0.756 → 1.041 (+37.7%) | 1.307 → 1.934 (+47.9%) | 120.000 → 120.000 (+0.0%) | 30.000 → 30.000 (+0.0%) | 0.000 → 0.000 | 0.000 → 0.000 | latency_p95_ms |
| timetable.invalid-id | 0.714 → 1.118 (+56.6%) | 1.082 → 1.823 (+68.6%) | 120.000 → 120.000 (+0.0%) | 30.000 → 30.000 (+0.0%) | 0.000 → 0.000 | 0.000 → 0.000 | latency_p95_ms |
| people-directory.invalid-id | 0.786 → 1.121 (+42.5%) | 1.208 → 2.820 (+133.4%) | 120.000 → 120.000 (+0.0%) | 30.000 → 30.000 (+0.0%) | 0.000 → 0.000 | 0.000 → 0.000 | latency_p95_ms |
| security.unauthenticated | 0.028 → 0.045 (+60.3%) | 0.101 → 0.223 (+121.2%) | 0.000 → 0.000 | 0.000 → 0.000 | 0.000 → 0.000 | 0.000 → 0.000 | none |
| delivery.provider-unavailable | 7.713 → 9.301 (+20.6%) | 10.988 → 17.539 (+59.6%) | 1140.000 → 1140.000 (+0.0%) | 30.000 → 30.000 (+0.0%) | 0.000 → 0.000 | 0.000 → 0.000 | job_duration_total_ms, latency_p50_ms, latency_p95_ms |
| delivery.render-failure | 7.215 → 7.450 (+3.3%) | 8.661 → 13.635 (+57.4%) | 1080.000 → 1080.000 (+0.0%) | 30.000 → 30.000 (+0.0%) | 0.000 → 0.000 | 0.000 → 0.000 | latency_p95_ms |
| delivery.idle | 4.836 → 4.905 (+1.4%) | 7.405 → 10.406 (+40.5%) | 720.000 → 720.000 (+0.0%) | 0.000 → 0.000 | 0.000 → 0.000 | 0.000 → 0.000 | latency_p95_ms |
| timetable.materialize-create | 5.282 → 6.143 (+16.3%) | 11.940 → 7.860 (-34.2%) | 570.000 → 570.000 (+0.0%) | 30.000 → 30.000 (+0.0%) | 0.000 → 0.000 | 0.000 → 0.000 | latency_p95_ms |
| timetable.materialize-existing | 4.119 → 4.524 (+9.8%) | 5.836 → 5.868 (+0.5%) | 510.000 → 510.000 (+0.0%) | 0.000 → 0.000 | 0.000 → 0.000 | 0.000 → 0.000 | none |

¹ HTTP: driver-reported rows returned or changed, not distinct database rows. Worker: outbox rows claimed or timetable instances created.

## Material changes

- `timetable.not-found` `latency_p95_ms` worst: 4.520 → 2.306
- `organization-tenancy.resolve` `latency_p95_ms` median: 2.792 → 3.659
- `organization-tenancy.resolve` `latency_p95_ms` worst: 3.116 → 3.755
- `facilities.update` `latency_p95_ms` median: 1.797 → 2.521
- `facilities.update` `latency_p95_ms` worst: 1.813 → 4.034
- `facilities.list` `latency_p95_ms` median: 2.532 → 4.390
- `facilities.list` `latency_p95_ms` worst: 2.641 → 6.211
- `school-structure.list` `latency_p50_ms` worst: 2.015 → 3.702
- `school-structure.list` `latency_p95_ms` median: 2.199 → 3.172
- `school-structure.list` `latency_p95_ms` worst: 2.716 → 7.053
- `people-directory.guardians` `latency_p95_ms` median: 1.871 → 3.095
- `people-directory.guardians` `latency_p95_ms` worst: 1.916 → 3.593
- `timetable.activities` `latency_p95_ms` median: 2.706 → 3.544
- `timetable.activities` `latency_p95_ms` worst: 2.767 → 3.663
- `timetable.categories` `latency_p50_ms` worst: 1.042 → 1.953
- `timetable.categories` `latency_p95_ms` median: 1.308 → 2.038
- `timetable.categories` `latency_p95_ms` worst: 1.369 → 4.310
- `school-calendar.periods` `latency_p50_ms` worst: 1.903 → 2.432
- `school-calendar.periods` `latency_p95_ms` median: 2.243 → 3.043
- `school-calendar.periods` `latency_p95_ms` worst: 2.266 → 9.023
- `care-plan.offerings` `latency_p50_ms` worst: 1.289 → 2.996
- `care-plan.offerings` `latency_p95_ms` median: 1.787 → 2.350
- `care-plan.offerings` `latency_p95_ms` worst: 1.818 → 7.295
- `communication.messages` `latency_p50_ms` median: 4.098 → 2.820
- `communication.messages` `latency_p50_ms` worst: 4.277 → 3.352
- `communication.messages` `latency_p95_ms` median: 4.792 → 3.450
- `appointments.calendar` `latency_p50_ms` worst: 2.508 → 3.343
- `appointments.calendar` `latency_p95_ms` median: 2.936 → 4.258
- `appointments.calendar` `latency_p95_ms` worst: 3.394 → 9.037
- `settings.schema` `latency_p50_ms` worst: 1.893 → 3.121
- `settings.schema` `latency_p95_ms` median: 2.508 → 3.397
- `settings.schema` `latency_p95_ms` worst: 2.702 → 5.992
- `meal-plan.list` `latency_p50_ms` worst: 1.152 → 2.510
- `meal-plan.list` `latency_p95_ms` median: 1.331 → 1.864
- `meal-plan.list` `latency_p95_ms` worst: 1.524 → 5.883
- `school-membership.staff` `latency_p50_ms` median: 4.041 → 5.402
- `school-membership.staff` `latency_p50_ms` worst: 4.136 → 5.665
- `school-membership.staff` `latency_p95_ms` median: 4.919 → 8.956
- `school-membership.staff` `latency_p95_ms` worst: 5.684 → 11.449
- `facilities.invalid-id` `latency_p95_ms` median: 1.177 → 1.899
- `facilities.invalid-id` `latency_p95_ms` worst: 1.307 → 1.934
- `timetable.invalid-id` `latency_p95_ms` worst: 1.082 → 1.823
- `people-directory.invalid-id` `latency_p95_ms` worst: 1.208 → 2.820
- `delivery.provider-unavailable` `latency_p50_ms` worst: 7.713 → 9.301
- `delivery.provider-unavailable` `latency_p95_ms` median: 8.934 → 16.124
- `delivery.provider-unavailable` `latency_p95_ms` worst: 10.988 → 17.539
- `delivery.provider-unavailable` `job_duration_total_ms` worst: 241.523 → 318.674
- `delivery.render-failure` `latency_p95_ms` worst: 8.661 → 13.635
- `delivery.idle` `latency_p95_ms` median: 5.074 → 8.540
- `delivery.idle` `latency_p95_ms` worst: 7.405 → 10.406
- `timetable.materialize-create` `latency_p95_ms` median: 5.877 → 7.741
- `timetable.materialize-create` `latency_p95_ms` worst: 11.940 → 7.860

## Classification counts across all scenarios, metrics, and statistics

- unchanged: 888
- within-tolerance: 58
- material: 52
- coverage: 100
