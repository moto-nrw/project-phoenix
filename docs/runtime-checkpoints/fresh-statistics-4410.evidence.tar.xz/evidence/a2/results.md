# Runtime workload checkpoint-1-v1: measured results

Values are median / worst across three runs. Latency uses nearest-rank percentiles.

| Scenario | p50 ms | p95 ms | Queries/run | Rows/run¹ | Pool wait ms | Lock observations |
|---|---:|---:|---:|---:|---:|---:|
| timetable.not-found | 0.961 / 1.080 | 1.375 / 1.731 | 150.000 / 150.000 | 30.000 / 30.000 | 0.000 / 0.000 | 0.000 / 0.000 |
| organization-tenancy.resolve | 2.477 / 2.867 | 3.179 / 4.366 | 390.000 / 390.000 | 90.000 / 90.000 | 0.000 / 0.000 | 0.000 / 0.000 |
| facilities.update | 1.468 / 2.122 | 1.793 / 4.226 | 210.000 / 210.000 | 120.000 / 120.000 | 0.000 / 0.000 | 0.000 / 0.000 |
| facilities.list | 1.851 / 2.430 | 2.443 / 3.956 | 210.000 / 210.000 | 390.000 / 390.000 | 0.000 / 0.000 | 0.000 / 0.000 |
| school-structure.list | 1.906 / 2.049 | 2.675 / 3.068 | 240.000 / 240.000 | 330.000 / 330.000 | 0.000 / 0.000 | 0.000 / 0.000 |
| people-directory.guardians | 1.463 / 1.569 | 1.808 / 2.121 | 180.000 / 180.000 | 1530.000 / 1530.000 | 0.000 / 0.000 | 0.000 / 0.000 |
| timetable.activities | 2.131 / 2.460 | 3.021 / 4.938 | 240.000 / 240.000 | 690.000 / 690.000 | 0.000 / 0.000 | 0.000 / 0.000 |
| timetable.categories | 1.061 / 1.373 | 1.302 / 1.845 | 150.000 / 150.000 | 360.000 / 360.000 | 0.000 / 0.000 | 0.000 / 0.000 |
| school-calendar.periods | 1.992 / 2.264 | 2.983 / 6.627 | 210.000 / 210.000 | 90.000 / 90.000 | 0.000 / 0.000 | 0.000 / 0.000 |
| care-plan.offerings | 1.474 / 1.542 | 1.923 / 2.601 | 180.000 / 180.000 | 330.000 / 330.000 | 0.000 / 0.000 | 0.000 / 0.000 |
| communication.messages | 4.324 / 4.505 | 4.801 / 4.937 | 150.000 / 150.000 | 30.000 / 30.000 | 0.000 / 0.000 | 0.000 / 0.000 |
| appointments.calendar | 2.730 / 2.820 | 3.485 / 3.974 | 270.000 / 270.000 | 90.000 / 90.000 | 0.000 / 0.000 | 0.000 / 0.000 |
| settings.schema | 1.914 / 1.979 | 2.438 / 2.889 | 150.000 / 150.000 | 30.000 / 30.000 | 0.000 / 0.000 | 0.000 / 0.000 |
| meal-plan.list | 1.254 / 1.515 | 1.745 / 2.073 | 180.000 / 180.000 | 30.000 / 30.000 | 0.000 / 0.000 | 0.000 / 0.000 |
| feedback.list | 0.960 / 1.031 | 1.251 / 1.279 | 150.000 / 150.000 | 30.000 / 30.000 | 0.000 / 0.000 | 0.000 / 0.000 |
| school-membership.staff | 3.915 / 4.023 | 5.153 / 5.691 | 450.000 / 450.000 | 1170.000 / 1170.000 | 0.000 / 0.000 | 0.000 / 0.000 |
| facilities.invalid-id | 0.736 / 0.984 | 0.986 / 1.860 | 120.000 / 120.000 | 30.000 / 30.000 | 0.000 / 0.000 | 0.000 / 0.000 |
| timetable.invalid-id | 0.679 / 0.790 | 1.109 / 1.216 | 120.000 / 120.000 | 30.000 / 30.000 | 0.000 / 0.000 | 0.000 / 0.000 |
| people-directory.invalid-id | 0.678 / 0.806 | 1.026 / 1.198 | 120.000 / 120.000 | 30.000 / 30.000 | 0.000 / 0.000 | 0.000 / 0.000 |
| security.unauthenticated | 0.027 / 0.042 | 0.037 / 0.084 | 0.000 / 0.000 | 0.000 / 0.000 | 0.000 / 0.000 | 0.000 / 0.000 |
| delivery.provider-unavailable | 7.351 / 7.390 | 8.506 / 11.076 | 1140.000 / 1140.000 | 30.000 / 30.000 | 0.000 / 0.000 | 0.000 / 0.000 |
| delivery.render-failure | 6.537 / 7.058 | 7.505 / 8.691 | 1080.000 / 1080.000 | 30.000 / 30.000 | 0.000 / 0.000 | 0.000 / 0.000 |
| delivery.idle | 4.416 / 4.462 | 5.634 / 5.863 | 720.000 / 720.000 | 0.000 / 0.000 | 0.000 / 0.000 | 0.000 / 0.000 |
| timetable.materialize-create | 4.816 / 4.870 | 5.744 / 7.026 | 570.000 / 570.000 | 30.000 / 30.000 | 0.000 / 0.000 | 0.000 / 0.000 |
| timetable.materialize-existing | 4.033 / 4.717 | 4.579 / 5.982 | 510.000 / 510.000 | 0.000 / 0.000 | 0.000 / 0.000 | 0.000 / 0.000 |

¹ HTTP: driver-reported rows returned or changed, not distinct database rows. Worker: outbox rows claimed or timetable instances created. Zero does not assert that every adapter has row instrumentation.

`summary.json` contains every numeric metric's three values, median and worst, stable errors, and nonzero raw counter deltas. Sampled Lock observations are not exact wait durations. Acquisition-statement timing is not used as lock-wait evidence.
