# Runtime workload checkpoint-1-v1: measured results

Values are median / worst across three runs. Latency uses nearest-rank percentiles.

| Scenario | p50 ms | p95 ms | Queries/run | Rows/run¹ | Pool wait ms | Lock observations |
|---|---:|---:|---:|---:|---:|---:|
| timetable.not-found | 1.001 / 1.140 | 1.400 / 1.695 | 150.000 / 150.000 | 30.000 / 30.000 | 0.000 / 0.000 | 0.000 / 0.000 |
| organization-tenancy.resolve | 2.689 / 2.699 | 3.475 / 4.119 | 390.000 / 390.000 | 90.000 / 90.000 | 0.000 / 0.000 | 0.000 / 0.000 |
| facilities.update | 1.361 / 1.523 | 1.852 / 2.008 | 210.000 / 210.000 | 120.000 / 120.000 | 0.000 / 0.000 | 0.000 / 0.000 |
| facilities.list | 1.709 / 1.935 | 2.083 / 2.500 | 210.000 / 210.000 | 390.000 / 390.000 | 0.000 / 0.000 | 0.000 / 0.000 |
| school-structure.list | 2.079 / 2.261 | 2.784 / 2.823 | 240.000 / 240.000 | 330.000 / 330.000 | 0.000 / 0.000 | 0.000 / 0.000 |
| people-directory.guardians | 1.547 / 1.658 | 1.923 / 2.005 | 180.000 / 180.000 | 1530.000 / 1530.000 | 0.000 / 0.000 | 0.000 / 0.000 |
| timetable.activities | 2.502 / 2.629 | 3.532 / 3.621 | 240.000 / 240.000 | 690.000 / 690.000 | 0.000 / 0.000 | 0.000 / 0.000 |
| timetable.categories | 1.201 / 1.228 | 1.608 / 2.103 | 150.000 / 150.000 | 360.000 / 360.000 | 0.000 / 0.000 | 0.000 / 0.000 |
| school-calendar.periods | 1.987 / 2.207 | 2.489 / 2.637 | 210.000 / 210.000 | 90.000 / 90.000 | 0.000 / 0.000 | 0.000 / 0.000 |
| care-plan.offerings | 1.115 / 1.713 | 2.003 / 2.225 | 180.000 / 180.000 | 330.000 / 330.000 | 0.000 / 0.000 | 0.000 / 0.000 |
| communication.messages | 2.644 / 2.668 | 3.347 / 3.352 | 150.000 / 150.000 | 30.000 / 30.000 | 0.000 / 0.000 | 0.000 / 0.000 |
| appointments.calendar | 2.691 / 2.861 | 3.663 / 3.859 | 270.000 / 270.000 | 90.000 / 90.000 | 0.000 / 0.000 | 0.000 / 0.000 |
| settings.schema | 1.958 / 2.168 | 2.673 / 2.747 | 150.000 / 150.000 | 30.000 / 30.000 | 0.000 / 0.000 | 0.000 / 0.000 |
| meal-plan.list | 1.229 / 1.281 | 1.413 / 1.954 | 180.000 / 180.000 | 30.000 / 30.000 | 0.000 / 0.000 | 0.000 / 0.000 |
| feedback.list | 0.933 / 0.982 | 1.235 / 1.399 | 150.000 / 150.000 | 30.000 / 30.000 | 0.000 / 0.000 | 0.000 / 0.000 |
| school-membership.staff | 4.360 / 4.389 | 6.276 / 6.403 | 450.000 / 450.000 | 1170.000 / 1170.000 | 0.000 / 0.000 | 0.000 / 0.000 |
| facilities.invalid-id | 0.805 / 0.808 | 1.154 / 1.174 | 120.000 / 120.000 | 30.000 / 30.000 | 0.000 / 0.000 | 0.000 / 0.000 |
| timetable.invalid-id | 0.750 / 0.975 | 1.030 / 1.331 | 120.000 / 120.000 | 30.000 / 30.000 | 0.000 / 0.000 | 0.000 / 0.000 |
| people-directory.invalid-id | 0.769 / 0.976 | 1.344 / 1.879 | 120.000 / 120.000 | 30.000 / 30.000 | 0.000 / 0.000 | 0.000 / 0.000 |
| security.unauthenticated | 0.026 / 0.030 | 0.063 / 0.101 | 0.000 / 0.000 | 0.000 / 0.000 | 0.000 / 0.000 | 0.000 / 0.000 |
| delivery.provider-unavailable | 7.966 / 8.253 | 10.758 / 16.400 | 1140.000 / 1140.000 | 30.000 / 30.000 | 0.000 / 0.000 | 0.000 / 0.000 |
| delivery.render-failure | 6.886 / 8.583 | 8.505 / 11.842 | 1080.000 / 1080.000 | 30.000 / 30.000 | 0.000 / 0.000 | 0.000 / 0.000 |
| delivery.idle | 4.693 / 4.893 | 5.675 / 6.541 | 720.000 / 720.000 | 0.000 / 0.000 | 0.000 / 0.000 | 0.000 / 0.000 |
| timetable.materialize-create | 5.520 / 5.756 | 6.468 / 8.234 | 570.000 / 570.000 | 30.000 / 30.000 | 0.000 / 0.000 | 0.000 / 0.000 |
| timetable.materialize-existing | 4.642 / 4.862 | 5.802 / 14.200 | 510.000 / 510.000 | 0.000 / 0.000 | 0.000 / 0.000 | 0.000 / 0.000 |

¹ HTTP: driver-reported rows returned or changed, not distinct database rows. Worker: outbox rows claimed or timetable instances created. Zero does not assert that every adapter has row instrumentation.

`summary.json` contains every numeric metric's three values, median and worst, stable errors, and nonzero raw counter deltas. Sampled Lock observations are not exact wait durations. Acquisition-statement timing is not used as lock-wait evidence.
