# Runtime workload checkpoint-1-v1: baseline versus candidate

Each cell shows baseline → candidate. Latency uses nearest-rank percentiles.
Latency changes count as material only beyond relative 20.0% and absolute 0.500 ms; any change to another metric is material. The Material column of each table lists only that table's statistic.

## Median of three runs

| Scenario | p50 ms | p95 ms | Queries/run | Rows/run¹ | Pool wait ms | Lock observations | Material |
|---|---:|---:|---:|---:|---:|---:|---|
| timetable.not-found | 0.961 → 0.978 (+1.7%) | 1.375 → 1.388 (+0.9%) | 150.000 → 150.000 (+0.0%) | 30.000 → 30.000 (+0.0%) | 0.000 → 0.000 | 0.000 → 0.000 | none |
| organization-tenancy.resolve | 2.477 → 2.391 (-3.5%) | 3.179 → 3.104 (-2.4%) | 390.000 → 390.000 (+0.0%) | 90.000 → 90.000 (+0.0%) | 0.000 → 0.000 | 0.000 → 0.000 | none |
| facilities.update | 1.468 → 1.290 (-12.1%) | 1.793 → 1.678 (-6.5%) | 210.000 → 210.000 (+0.0%) | 120.000 → 120.000 (+0.0%) | 0.000 → 0.000 | 0.000 → 0.000 | none |
| facilities.list | 1.851 → 1.659 (-10.4%) | 2.443 → 2.031 (-16.9%) | 210.000 → 210.000 (+0.0%) | 390.000 → 390.000 (+0.0%) | 0.000 → 0.000 | 0.000 → 0.000 | none |
| school-structure.list | 1.906 → 1.842 (-3.3%) | 2.675 → 2.274 (-15.0%) | 240.000 → 240.000 (+0.0%) | 330.000 → 330.000 (+0.0%) | 0.000 → 0.000 | 0.000 → 0.000 | none |
| people-directory.guardians | 1.463 → 1.370 (-6.3%) | 1.808 → 1.664 (-8.0%) | 180.000 → 180.000 (+0.0%) | 1530.000 → 1530.000 (+0.0%) | 0.000 → 0.000 | 0.000 → 0.000 | none |
| timetable.activities | 2.131 → 2.061 (-3.3%) | 3.021 → 2.321 (-23.2%) | 240.000 → 240.000 (+0.0%) | 690.000 → 690.000 (+0.0%) | 0.000 → 0.000 | 0.000 → 0.000 | latency_p95_ms |
| timetable.categories | 1.061 → 1.029 (-3.1%) | 1.302 → 1.423 (+9.3%) | 150.000 → 150.000 (+0.0%) | 360.000 → 360.000 (+0.0%) | 0.000 → 0.000 | 0.000 → 0.000 | none |
| school-calendar.periods | 1.992 → 1.704 (-14.5%) | 2.983 → 2.154 (-27.8%) | 210.000 → 210.000 (+0.0%) | 90.000 → 90.000 (+0.0%) | 0.000 → 0.000 | 0.000 → 0.000 | latency_p95_ms |
| care-plan.offerings | 1.474 → 1.249 (-15.3%) | 1.923 → 1.514 (-21.3%) | 180.000 → 180.000 (+0.0%) | 330.000 → 330.000 (+0.0%) | 0.000 → 0.000 | 0.000 → 0.000 | none |
| communication.messages | 4.324 → 2.414 (-44.2%) | 4.801 → 3.015 (-37.2%) | 150.000 → 150.000 (+0.0%) | 30.000 → 30.000 (+0.0%) | 0.000 → 0.000 | 0.000 → 0.000 | latency_p50_ms, latency_p95_ms |
| appointments.calendar | 2.730 → 2.240 (-17.9%) | 3.485 → 2.796 (-19.8%) | 270.000 → 270.000 (+0.0%) | 90.000 → 90.000 (+0.0%) | 0.000 → 0.000 | 0.000 → 0.000 | none |
| settings.schema | 1.914 → 1.616 (-15.6%) | 2.438 → 2.182 (-10.5%) | 150.000 → 150.000 (+0.0%) | 30.000 → 30.000 (+0.0%) | 0.000 → 0.000 | 0.000 → 0.000 | none |
| meal-plan.list | 1.254 → 1.038 (-17.2%) | 1.745 → 1.322 (-24.2%) | 180.000 → 180.000 (+0.0%) | 30.000 → 30.000 (+0.0%) | 0.000 → 0.000 | 0.000 → 0.000 | none |
| feedback.list | 0.960 → 0.913 (-4.9%) | 1.251 → 1.122 (-10.3%) | 150.000 → 150.000 (+0.0%) | 30.000 → 30.000 (+0.0%) | 0.000 → 0.000 | 0.000 → 0.000 | none |
| school-membership.staff | 3.915 → 3.490 (-10.9%) | 5.153 → 3.996 (-22.4%) | 450.000 → 450.000 (+0.0%) | 1170.000 → 1170.000 (+0.0%) | 0.000 → 0.000 | 0.000 → 0.000 | latency_p95_ms |
| facilities.invalid-id | 0.736 → 0.726 (-1.4%) | 0.986 → 1.137 (+15.3%) | 120.000 → 120.000 (+0.0%) | 30.000 → 30.000 (+0.0%) | 0.000 → 0.000 | 0.000 → 0.000 | none |
| timetable.invalid-id | 0.679 → 0.691 (+1.8%) | 1.109 → 0.911 (-17.9%) | 120.000 → 120.000 (+0.0%) | 30.000 → 30.000 (+0.0%) | 0.000 → 0.000 | 0.000 → 0.000 | none |
| people-directory.invalid-id | 0.678 → 0.667 (-1.7%) | 1.026 → 0.792 (-22.8%) | 120.000 → 120.000 (+0.0%) | 30.000 → 30.000 (+0.0%) | 0.000 → 0.000 | 0.000 → 0.000 | none |
| security.unauthenticated | 0.027 → 0.027 (+0.5%) | 0.037 → 0.084 (+124.6%) | 0.000 → 0.000 | 0.000 → 0.000 | 0.000 → 0.000 | 0.000 → 0.000 | none |
| delivery.provider-unavailable | 7.351 → 6.976 (-5.1%) | 8.506 → 8.069 (-5.1%) | 1140.000 → 1140.000 (+0.0%) | 30.000 → 30.000 (+0.0%) | 0.000 → 0.000 | 0.000 → 0.000 | none |
| delivery.render-failure | 6.537 → 6.276 (-4.0%) | 7.505 → 7.253 (-3.4%) | 1080.000 → 1080.000 (+0.0%) | 30.000 → 30.000 (+0.0%) | 0.000 → 0.000 | 0.000 → 0.000 | none |
| delivery.idle | 4.416 → 4.218 (-4.5%) | 5.634 → 4.982 (-11.6%) | 720.000 → 720.000 (+0.0%) | 0.000 → 0.000 | 0.000 → 0.000 | 0.000 → 0.000 | none |
| timetable.materialize-create | 4.816 → 4.609 (-4.3%) | 5.744 → 5.497 (-4.3%) | 570.000 → 570.000 (+0.0%) | 30.000 → 30.000 (+0.0%) | 0.000 → 0.000 | 0.000 → 0.000 | none |
| timetable.materialize-existing | 4.033 → 4.082 (+1.2%) | 4.579 → 4.735 (+3.4%) | 510.000 → 510.000 (+0.0%) | 0.000 → 0.000 | 0.000 → 0.000 | 0.000 → 0.000 | none |

## Worst of three runs

The worst run is the maximum of each metric across runs, chosen per metric.

| Scenario | p50 ms | p95 ms | Queries/run | Rows/run¹ | Pool wait ms | Lock observations | Material |
|---|---:|---:|---:|---:|---:|---:|---|
| timetable.not-found | 1.080 → 1.219 (+12.9%) | 1.731 → 2.720 (+57.2%) | 150.000 → 150.000 (+0.0%) | 30.000 → 30.000 (+0.0%) | 0.000 → 0.000 | 0.000 → 0.000 | latency_p95_ms |
| organization-tenancy.resolve | 2.867 → 2.436 (-15.0%) | 4.366 → 3.229 (-26.0%) | 390.000 → 390.000 (+0.0%) | 90.000 → 90.000 (+0.0%) | 0.000 → 0.000 | 0.000 → 0.000 | latency_p95_ms |
| facilities.update | 2.122 → 1.410 (-33.6%) | 4.226 → 1.715 (-59.4%) | 210.000 → 210.000 (+0.0%) | 120.000 → 120.000 (+0.0%) | 0.000 → 0.000 | 0.000 → 0.000 | latency_p50_ms, latency_p95_ms |
| facilities.list | 2.430 → 1.673 (-31.2%) | 3.956 → 2.175 (-45.0%) | 210.000 → 210.000 (+0.0%) | 390.000 → 390.000 (+0.0%) | 0.000 → 0.000 | 0.000 → 0.000 | latency_p50_ms, latency_p95_ms |
| school-structure.list | 2.049 → 2.026 (-1.1%) | 3.068 → 2.744 (-10.6%) | 240.000 → 240.000 (+0.0%) | 330.000 → 330.000 (+0.0%) | 0.000 → 0.000 | 0.000 → 0.000 | none |
| people-directory.guardians | 1.569 → 1.573 (+0.2%) | 2.121 → 1.867 (-12.0%) | 180.000 → 180.000 (+0.0%) | 1530.000 → 1530.000 (+0.0%) | 0.000 → 0.000 | 0.000 → 0.000 | none |
| timetable.activities | 2.460 → 2.121 (-13.8%) | 4.938 → 2.472 (-50.0%) | 240.000 → 240.000 (+0.0%) | 690.000 → 690.000 (+0.0%) | 0.000 → 0.000 | 0.000 → 0.000 | latency_p95_ms |
| timetable.categories | 1.373 → 1.067 (-22.3%) | 1.845 → 1.472 (-20.2%) | 150.000 → 150.000 (+0.0%) | 360.000 → 360.000 (+0.0%) | 0.000 → 0.000 | 0.000 → 0.000 | none |
| school-calendar.periods | 2.264 → 1.705 (-24.7%) | 6.627 → 2.288 (-65.5%) | 210.000 → 210.000 (+0.0%) | 90.000 → 90.000 (+0.0%) | 0.000 → 0.000 | 0.000 → 0.000 | latency_p50_ms, latency_p95_ms |
| care-plan.offerings | 1.542 → 1.254 (-18.7%) | 2.601 → 1.598 (-38.5%) | 180.000 → 180.000 (+0.0%) | 330.000 → 330.000 (+0.0%) | 0.000 → 0.000 | 0.000 → 0.000 | latency_p95_ms |
| communication.messages | 4.505 → 2.471 (-45.1%) | 4.937 → 3.027 (-38.7%) | 150.000 → 150.000 (+0.0%) | 30.000 → 30.000 (+0.0%) | 0.000 → 0.000 | 0.000 → 0.000 | latency_p50_ms, latency_p95_ms |
| appointments.calendar | 2.820 → 2.296 (-18.6%) | 3.974 → 2.982 (-25.0%) | 270.000 → 270.000 (+0.0%) | 90.000 → 90.000 (+0.0%) | 0.000 → 0.000 | 0.000 → 0.000 | latency_p95_ms |
| settings.schema | 1.979 → 1.785 (-9.8%) | 2.889 → 2.289 (-20.8%) | 150.000 → 150.000 (+0.0%) | 30.000 → 30.000 (+0.0%) | 0.000 → 0.000 | 0.000 → 0.000 | latency_p95_ms |
| meal-plan.list | 1.515 → 1.120 (-26.0%) | 2.073 → 1.513 (-27.0%) | 180.000 → 180.000 (+0.0%) | 30.000 → 30.000 (+0.0%) | 0.000 → 0.000 | 0.000 → 0.000 | latency_p95_ms |
| feedback.list | 1.031 → 0.926 (-10.2%) | 1.279 → 1.173 (-8.3%) | 150.000 → 150.000 (+0.0%) | 30.000 → 30.000 (+0.0%) | 0.000 → 0.000 | 0.000 → 0.000 | none |
| school-membership.staff | 4.023 → 3.919 (-2.6%) | 5.691 → 4.772 (-16.2%) | 450.000 → 450.000 (+0.0%) | 1170.000 → 1170.000 (+0.0%) | 0.000 → 0.000 | 0.000 → 0.000 | none |
| facilities.invalid-id | 0.984 → 0.792 (-19.4%) | 1.860 → 1.149 (-38.2%) | 120.000 → 120.000 (+0.0%) | 30.000 → 30.000 (+0.0%) | 0.000 → 0.000 | 0.000 → 0.000 | latency_p95_ms |
| timetable.invalid-id | 0.790 → 0.703 (-11.0%) | 1.216 → 1.009 (-17.0%) | 120.000 → 120.000 (+0.0%) | 30.000 → 30.000 (+0.0%) | 0.000 → 0.000 | 0.000 → 0.000 | none |
| people-directory.invalid-id | 0.806 → 0.732 (-9.2%) | 1.198 → 0.927 (-22.6%) | 120.000 → 120.000 (+0.0%) | 30.000 → 30.000 (+0.0%) | 0.000 → 0.000 | 0.000 → 0.000 | none |
| security.unauthenticated | 0.042 → 0.037 (-12.9%) | 0.084 → 0.098 (+16.2%) | 0.000 → 0.000 | 0.000 → 0.000 | 0.000 → 0.000 | 0.000 → 0.000 | none |
| delivery.provider-unavailable | 7.390 → 7.280 (-1.5%) | 11.076 → 8.295 (-25.1%) | 1140.000 → 1140.000 (+0.0%) | 30.000 → 30.000 (+0.0%) | 0.000 → 0.000 | 0.000 → 0.000 | latency_p95_ms |
| delivery.render-failure | 7.058 → 6.558 (-7.1%) | 8.691 → 7.426 (-14.6%) | 1080.000 → 1080.000 (+0.0%) | 30.000 → 30.000 (+0.0%) | 0.000 → 0.000 | 0.000 → 0.000 | none |
| delivery.idle | 4.462 → 4.252 (-4.7%) | 5.863 → 5.065 (-13.6%) | 720.000 → 720.000 (+0.0%) | 0.000 → 0.000 | 0.000 → 0.000 | 0.000 → 0.000 | none |
| timetable.materialize-create | 4.870 → 4.902 (+0.6%) | 7.026 → 6.449 (-8.2%) | 570.000 → 570.000 (+0.0%) | 30.000 → 30.000 (+0.0%) | 0.000 → 0.000 | 0.000 → 0.000 | none |
| timetable.materialize-existing | 4.717 → 4.174 (-11.5%) | 5.982 → 4.883 (-18.4%) | 510.000 → 510.000 (+0.0%) | 0.000 → 0.000 | 0.000 → 0.000 | 0.000 → 0.000 | none |

¹ HTTP: driver-reported rows returned or changed, not distinct database rows. Worker: outbox rows claimed or timetable instances created.

## Material changes

- `timetable.not-found` `latency_p95_ms` worst: 1.731 → 2.720
- `organization-tenancy.resolve` `latency_p95_ms` worst: 4.366 → 3.229
- `facilities.update` `latency_p50_ms` worst: 2.122 → 1.410
- `facilities.update` `latency_p95_ms` worst: 4.226 → 1.715
- `facilities.list` `latency_p50_ms` worst: 2.430 → 1.673
- `facilities.list` `latency_p95_ms` worst: 3.956 → 2.175
- `timetable.activities` `latency_p95_ms` median: 3.021 → 2.321
- `timetable.activities` `latency_p95_ms` worst: 4.938 → 2.472
- `school-calendar.periods` `latency_p50_ms` worst: 2.264 → 1.705
- `school-calendar.periods` `latency_p95_ms` median: 2.983 → 2.154
- `school-calendar.periods` `latency_p95_ms` worst: 6.627 → 2.288
- `care-plan.offerings` `latency_p95_ms` worst: 2.601 → 1.598
- `communication.messages` `latency_p50_ms` median: 4.324 → 2.414
- `communication.messages` `latency_p50_ms` worst: 4.505 → 2.471
- `communication.messages` `latency_p95_ms` median: 4.801 → 3.015
- `communication.messages` `latency_p95_ms` worst: 4.937 → 3.027
- `appointments.calendar` `latency_p95_ms` worst: 3.974 → 2.982
- `settings.schema` `latency_p95_ms` worst: 2.889 → 2.289
- `meal-plan.list` `latency_p95_ms` worst: 2.073 → 1.513
- `school-membership.staff` `latency_p95_ms` median: 5.153 → 3.996
- `facilities.invalid-id` `latency_p95_ms` worst: 1.860 → 1.149
- `delivery.provider-unavailable` `latency_p95_ms` worst: 11.076 → 8.295

## Classification counts across all scenarios, metrics, and statistics

- unchanged: 888
- within-tolerance: 88
- material: 22
- coverage: 100
