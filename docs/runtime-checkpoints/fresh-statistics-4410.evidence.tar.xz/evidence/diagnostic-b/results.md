# Runtime workload checkpoint-1-v1: measured results

Values are median / worst across three runs. Latency uses nearest-rank percentiles.

| Scenario | p50 ms | p95 ms | Queries/run | Rows/run¹ | Pool wait ms | Lock observations |
|---|---:|---:|---:|---:|---:|---:|
| timetable.not-found | 1.063 / 1.222 | 1.696 / 1.696 | 150.000 / 150.000 | 30.000 / 30.000 | 0.000 / 0.000 | 0.000 / 0.000 |
| organization-tenancy.resolve | 2.588 / 4.071 | 3.457 / 5.310 | 390.000 / 390.000 | 90.000 / 90.000 | 0.000 / 0.000 | 0.000 / 0.000 |
| facilities.update | 1.523 / 1.595 | 2.254 / 2.322 | 210.000 / 210.000 | 120.000 / 120.000 | 0.000 / 0.000 | 0.000 / 0.000 |
| facilities.list | 2.049 / 2.122 | 2.654 / 4.879 | 210.000 / 210.000 | 390.000 / 390.000 | 0.000 / 0.000 | 0.000 / 0.000 |
| school-structure.list | 1.998 / 2.325 | 3.011 / 3.255 | 240.000 / 240.000 | 330.000 / 330.000 | 0.000 / 0.000 | 0.000 / 0.000 |
| people-directory.guardians | 1.761 / 1.851 | 2.602 / 2.896 | 180.000 / 180.000 | 1530.000 / 1530.000 | 0.000 / 0.000 | 0.000 / 0.000 |
| timetable.activities | 2.281 / 2.445 | 2.706 / 3.306 | 240.000 / 240.000 | 690.000 / 690.000 | 0.000 / 0.000 | 0.000 / 0.000 |
| timetable.categories | 1.105 / 1.162 | 1.591 / 1.838 | 150.000 / 150.000 | 360.000 / 360.000 | 0.000 / 0.000 | 0.000 / 0.000 |
| school-calendar.periods | 1.760 / 1.930 | 2.113 / 3.318 | 210.000 / 210.000 | 90.000 / 90.000 | 0.000 / 0.000 | 0.000 / 0.000 |
| care-plan.offerings | 1.392 / 1.661 | 1.742 / 2.182 | 180.000 / 180.000 | 330.000 / 330.000 | 0.000 / 0.000 | 0.000 / 0.000 |
| communication.messages | 2.677 / 2.782 | 3.023 / 3.320 | 150.000 / 150.000 | 30.000 / 30.000 | 0.000 / 0.000 | 0.000 / 0.000 |
| appointments.calendar | 2.586 / 2.721 | 3.249 / 3.744 | 270.000 / 270.000 | 90.000 / 90.000 | 0.000 / 0.000 | 0.000 / 0.000 |
| settings.schema | 1.934 / 2.057 | 2.621 / 3.058 | 150.000 / 150.000 | 30.000 / 30.000 | 0.000 / 0.000 | 0.000 / 0.000 |
| meal-plan.list | 1.375 / 1.486 | 1.716 / 2.095 | 180.000 / 180.000 | 30.000 / 30.000 | 0.000 / 0.000 | 0.000 / 0.000 |
| feedback.list | 0.954 / 1.032 | 1.288 / 1.360 | 150.000 / 150.000 | 30.000 / 30.000 | 0.000 / 0.000 | 0.000 / 0.000 |
| school-membership.staff | 3.879 / 4.004 | 4.877 / 7.235 | 450.000 / 450.000 | 1170.000 / 1170.000 | 0.000 / 0.000 | 0.000 / 0.000 |
| facilities.invalid-id | 0.657 / 0.682 | 1.009 / 1.029 | 120.000 / 120.000 | 30.000 / 30.000 | 0.000 / 0.000 | 0.000 / 0.000 |
| timetable.invalid-id | 0.742 / 0.889 | 1.139 / 1.254 | 120.000 / 120.000 | 30.000 / 30.000 | 0.000 / 0.000 | 0.000 / 0.000 |
| people-directory.invalid-id | 0.691 / 0.770 | 1.085 / 1.107 | 120.000 / 120.000 | 30.000 / 30.000 | 0.000 / 0.000 | 0.000 / 0.000 |
| security.unauthenticated | 0.028 / 0.043 | 0.131 / 0.161 | 0.000 / 0.000 | 0.000 / 0.000 | 0.000 / 0.000 | 0.000 / 0.000 |
| delivery.provider-unavailable | 7.541 / 8.013 | 9.104 / 9.364 | 1140.000 / 1140.000 | 30.000 / 30.000 | 0.000 / 0.000 | 0.000 / 0.000 |
| delivery.render-failure | 7.120 / 7.233 | 8.270 / 9.275 | 1080.000 / 1080.000 | 30.000 / 30.000 | 0.000 / 0.000 | 0.000 / 0.000 |
| delivery.idle | 4.349 / 4.440 | 5.258 / 5.450 | 720.000 / 720.000 | 0.000 / 0.000 | 0.000 / 0.000 | 0.000 / 0.000 |
| timetable.materialize-create | 5.116 / 5.120 | 6.616 / 6.937 | 570.000 / 570.000 | 30.000 / 30.000 | 0.000 / 0.000 | 0.000 / 0.000 |
| timetable.materialize-existing | 4.278 / 4.816 | 5.474 / 5.805 | 510.000 / 510.000 | 0.000 / 0.000 | 0.000 / 0.000 | 0.000 / 0.000 |

¹ HTTP: driver-reported rows returned or changed, not distinct database rows. Worker: outbox rows claimed or timetable instances created. Zero does not assert that every adapter has row instrumentation.

`summary.json` contains every numeric metric's three values, median and worst, stable errors, and nonzero raw counter deltas. Sampled Lock observations are not exact wait durations. Acquisition-statement timing is not used as lock-wait evidence.
