#!/bin/bash
set -euo pipefail
root=$(git rev-parse --show-toplevel)
cd "$root"
scripts/run-go-toolchain.sh go -C backend test -tags=testhooks -c ./api -o "$root/tmp/4410/candidate.test"
for variant in baseline diagnostic-a diagnostic-b; do
 GOFLAGS="-p=4 -overlay=$root/tmp/4410/$variant-overlay.json" scripts/run-go-toolchain.sh go -C backend test -tags=testhooks -c ./api -o "$root/tmp/4410/$variant.test"
done
