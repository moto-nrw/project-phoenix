import json,pathlib
root=pathlib.Path.cwd(); out=root/'tmp/4410/setup'; replacements={}
p=root/'backend/internal/testdb/template.go'; s=p.read_text(); start=s.index('func ensureAuthRolePassword('); end=s.index('\nfunc quoteLiteral',start)
s=s[:start]+'''func ensureAuthRolePassword(ctx context.Context, conn *sql.Conn) error {
    // Local verification only: common.md forbids cluster-global role writes.
    return conn.QueryRowContext(ctx, "SELECT 1").Scan(new(int))
}
'''+s[end:]
pin=out/'template-pin.go';pin.write_text(s);replacements[str(p)]=str(pin)
(out/'pin-overlay.json').write_text(json.dumps({'Replace':replacements}))
p=root/'backend/database/migrations/001014001_create_tenant_roles.go';s=p.read_text().replace('ALTER ROLE phoenix_auth SET search_path TO public, platform;', "DO $$ BEGIN EXECUTE format('ALTER DATABASE %I SET search_path TO public, platform', current_database()); END $$;")
f=out/'tenant-roles.go';f.write_text(s);replacements[str(p)]=str(f)
p=root/'backend/database/migrations/001015403_demo_runtime_role.go';s=p.read_text().replace('CREATE ROLE phoenix_demo LOGIN NOINHERIT;', 'CREATE ROLE phoenix_demo LOGIN NOINHERIT;')
# No demo runtime is exercised; the fresh role has no password until configured.
start=s.index('\tif password != "" {\n');end=s.index('\n\treturn nil',start);s=s[:start]+s[end:]
f=out/'demo-role.go';f.write_text(s);replacements[str(p)]=str(f)
(out/'setup-overlay.json').write_text(json.dumps({'Replace':replacements}))
