import json,pathlib
r=pathlib.Path.cwd();o=r/'tmp/4410';p=r/'backend/api/runtime_checkpoint_test.go';s=p.read_text()
a=s.replace('\t_, err = db.ExecContext(context.Background(), "ANALYZE")\n\trequire.NoError(t, err, "collect checkpoint fixture statistics before warm-ups")\n','').replace('"planner_statistics":             "fresh statistics"','"planner_statistics":             "no explicit fixture ANALYZE"').replace('"planner_statistics_preparation": "ANALYZE entire disposable database after fixture setup, before warm-ups and measurement"','"planner_statistics_preparation": "historical harness condition (no explicit ANALYZE)"')
# Account for gofmt alignment independently.
a=a.replace('"planner_statistics": "fresh statistics"','"planner_statistics": "no explicit fixture ANALYZE"')
f=o/'baseline.go';f.write_text(a);(o/'baseline-overlay.json').write_text(json.dumps({'Replace':{str(p):str(f)}}))
diag='''
            if scenario.Name == "communication.messages" {
                for _, query := range counter.Queries() {
                    if !strings.HasPrefix(strings.ToLower(query), "select") || !strings.Contains(query, "student_profiles") { continue }
                    tx, planErr := db.Begin()
                    require.NoError(t, planErr)
                    _, planErr = tx.ExecContext(context.Background(), "SET LOCAL ROLE phoenix_tenant")
                    require.NoError(t, planErr)
                    _, planErr = tx.ExecContext(context.Background(), "SELECT set_config('app.current_tenant_id', ?, true)", fmt.Sprint(testpkg.Tenant(t)))
                    require.NoError(t, planErr)
                    var plan string
                    require.NoError(t, tx.NewRaw("EXPLAIN (ANALYZE, BUFFERS, FORMAT JSON) " + query).Scan(context.Background(), &plan))
                    require.NoError(t, tx.Rollback())
                    plans, _ := environment["diagnostic_communication_plans"].([]any)
                    environment["diagnostic_communication_plans"] = append(plans, map[string]any{"sql":query,"plan":json.RawMessage(plan)})
                }
            }
'''
for name,src in [('diagnostic-a',a),('diagnostic-b',s)]:
 src=src.replace('\t\t\tresult.Deadlocks = deadlocks() - deadlocksBefore',diag+'\n\t\t\tresult.Deadlocks = deadlocks() - deadlocksBefore',1)
 f=o/(name+'.go');f.write_text(src);(o/(name+'-overlay.json')).write_text(json.dumps({'Replace':{str(p):str(f)}}))
